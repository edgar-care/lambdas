# Installer Hugging Face si nécessaire
# pip install transformers torch

import torch
from transformers import CamembertModel, CamembertTokenizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

# Charger le modèle et le tokenizer CamemBERT
model_name = "camembert-base"
tokenizer = CamembertTokenizer.from_pretrained(model_name)
model = CamembertModel.from_pretrained(model_name)

# Fonction pour extraire l'embedding de la phrase
def get_sentence_embedding(sentence, model, tokenizer):
    inputs = tokenizer(sentence, return_tensors="pt", padding=True, truncation=True, max_length=128)
    with torch.no_grad():
        outputs = model(**inputs)
    # Utiliser l'output [CLS] (le token de pooler) pour la représentation de phrase
    embedding = outputs.pooler_output
    return embedding

# Fonction pour calculer la similarité cosinus entre deux phrases
def cosine_similarity_between_sentences(sentence1, sentence2, model, tokenizer):
    embedding1 = get_sentence_embedding(sentence1, model, tokenizer)
    embedding2 = get_sentence_embedding(sentence2, model, tokenizer)

    # Convertir les embeddings en numpy pour utiliser sklearn cosine_similarity
    embedding1 = embedding1.cpu().numpy()
    embedding2 = embedding2.cpu().numpy()

    # Calculer la similarité cosinus
    similarity = cosine_similarity(embedding1, embedding2)
    return similarity[0][0]

# Phrases à comparer
sentence1 = "je me sens brassé"
sentence2 = "se sentir brassé"
sentence3 = "mal quand j'avale"

# Calcul de la similarité
similarity_1_2 = cosine_similarity_between_sentences(sentence1, sentence2, model, tokenizer)
similarity_1_3 = cosine_similarity_between_sentences(sentence1, sentence3, model, tokenizer)

print(f"Similarité entre '{sentence1}' et '{sentence2}': {similarity_1_2}")
print(f"Similarité entre '{sentence1}' et '{sentence3}': {similarity_1_3}")
